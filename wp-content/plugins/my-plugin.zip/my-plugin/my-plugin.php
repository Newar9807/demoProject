<?php
/*
* Plugin Name: My Plugin
* Description: This is Test Plugin
* Version: 1.0
* Author: Samir
* Author URI: https://authoruri.com
*/

// ========================== //
// Direct echo is not allowed //
// ========================== //

// => This checks if the plugin is accessed from wordpress or not 
if (!defined('ABSPATH')) 
{
    header("Location: /");
    die('Plugin accessed by unauthorised person');
}

function my_plugin_activation()
{
    // =================================================== //
    // This function is called when my-plugin is activated //
    // =================================================== //
    // echo ($wpbs.' '.$table_prefix);
    global $wpdb, $table_prefix;
    $wp_emp = $table_prefix. 'emp';
    $q = "CREATE TABLE IF NOT EXISTS `$wp_emp` (`ID` INT UNSIGNED NOT NULL,`name` VARCHAR(50) NOT NULL,`email` VARCHAR(100) NOT NULL,`status` TINYINT NOT NULL);";
    $wpdb->query($q);
    $q = "INSERT INTO `wp_emp` (`id`, `name`, `email`, `status`) VALUES (1,'John Doe', 'johndoe@example.com', 1);";
    $wpdb->query($q);
    
}
register_activation_hook( __FILE__, 'my_plugin_activation');

function my_plugin_deactivation()
{
    // ===================================================== //
    // This function is called when my-plugin is deactivated //
    // ===================================================== //
    global $wpdb, $table_prefix;
    $wp_emp = $table_prefix. 'emp';
    $q = "TRUNCATE TABLE `$wp_emp`;";
    $wpdb->query($q);
    
}
register_deactivation_hook( __FILE__, 'my_plugin_deactivation');

function short_code_function()
{
    // ===================================== //
    // This function for short code function //
    // ===================================== //
    return "Short code test";

}

add_shortcode('short-code', 'short_code_function');