<?php
/* Created for security reason */
echo "Security Barrier";